# Third-Party Libraries
* [WiFi101 (WINC1500)](https://github.com/arduino-libraries/WiFi101)
* [Ethernet2 (W5500)](https://github.com/adafruit/Ethernet2)
* [LMIC - LoraMAC-in-C (RFM9X)](https://github.com/matthijskooijman/arduino-lmic)
* [Adafruit_Sensor](https://github.com/adafruit/Adafruit_Sensor)
* [Adafruit_BMP280](https://github.com/adafruit/Adafruit_BMP280_Library)
* [Adafruit_BME280](https://github.com/adafruit/Adafruit_BME280_Library)
* [Adafruit_BME680](https://github.com/adafruit/Adafruit_BME680)
